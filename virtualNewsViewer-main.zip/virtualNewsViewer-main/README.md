# virtualNewsViewer
This project is made for my school assignments. The intent is to make a news website based around Virtual Reality technologies.
